﻿using EmployeeManagement.DAL.Interfaces;
using EmployeeManagement.Domain.DTOs;
using EmployeeManagement.Domain.Models;
using EmployeeManagement.Service.Interfaces;

namespace EmployeeManagement.Service.Services
{
    public class DepartmentService : IDepartmentService
    {
        private readonly IDepartmentRepository _repo;

        public DepartmentService(IDepartmentRepository repo)
        {
            _repo = repo;
        }

        public async Task<IEnumerable<Department>> GetAllAsync()
        {
            return await _repo.GetAllAsync();
        }

        public async Task<Department?> GetByIdAsync(int id)
        {
            return await _repo.GetByIdAsync(id);
        }

        public async Task<Department> InsertAsync(DepartmentCreateDto dto, int createdBy)
        {
            return await _repo.InsertAsync(dto, createdBy);
        }

        public async Task<Department> UpdateAsync(int id, DepartmentUpdateDto dto, int updatedBy)
        {
            return await _repo.UpdateAsync(id, dto, updatedBy);
        }

        public async Task<string> DeleteAsync(int id)
        {
            return await _repo.DeleteAsync(id);
        }
    }
}