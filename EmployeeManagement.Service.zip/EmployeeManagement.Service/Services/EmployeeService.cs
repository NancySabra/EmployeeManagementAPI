﻿using EmployeeManagement.DAL.Interfaces;
using EmployeeManagement.Domain.DTOs;
using EmployeeManagement.Domain.Models;
using EmployeeManagement.Service.Interfaces;

namespace EmployeeManagement.Service.Services
{
    public class EmployeeService : IEmployeeService
    {
        private readonly IEmployeeRepository _repo;

        public EmployeeService(IEmployeeRepository repo)
        {
            _repo = repo;
        }

        public async Task<IEnumerable<Employee>> GetAllAsync()
        {
            return await _repo.GetAllAsync();
        }

        public async Task<Employee?> GetByIdAsync(int id)
        {
            return await _repo.GetByIdAsync(id);
        }

        public async Task<IEnumerable<Employee>> GetByDepartmentAsync(int departmentId)
        {
            return await _repo.GetByDepartmentAsync(departmentId);
        }

        public async Task<Employee> InsertAsync(EmployeeCreateDto dto, int createdBy)
        {
            return await _repo.InsertAsync(dto, createdBy);
        }

        public async Task<Employee> UpdateAsync(int id, EmployeeUpdateDto dto, int updatedBy)
        {
            return await _repo.UpdateAsync(id, dto, updatedBy);
        }

        public async Task<string> DeleteAsync(int id, int updatedBy)
        {
            return await _repo.DeleteAsync(id, updatedBy);
        }
    }
}