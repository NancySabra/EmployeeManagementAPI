﻿using EmployeeManagement.Domain.DTOs;
using EmployeeManagement.Domain.Models;

namespace EmployeeManagement.Service.Interfaces
{
    public interface IEmployeeService
    {
        Task<IEnumerable<Employee>> GetAllAsync();
        Task<Employee?> GetByIdAsync(int id);
        Task<IEnumerable<Employee>> GetByDepartmentAsync(int departmentId);
        Task<Employee> InsertAsync(EmployeeCreateDto dto, int createdBy);
        Task<Employee> UpdateAsync(int id, EmployeeUpdateDto dto, int updatedBy);
        Task<string> DeleteAsync(int id, int updatedBy);
    }
}