﻿using System.Data;
using Dapper;
using EmployeeManagement.Domain.DTOs;
using EmployeeManagement.Domain.Models;
using EmployeeManagement.DAL.Interfaces;

namespace EmployeeManagement.DAL.Repositories
{
    public class DepartmentRepository : IDepartmentRepository
    {
        private readonly IDbConnection _db;

        public DepartmentRepository(IDbConnection db)
        {
            _db = db;
        }

        public async Task<IEnumerable<Department>> GetAllAsync()
        {
            var result = await _db.QueryAsync<Department>(
                "dbo.usp_Department_GetAll",
                commandType: CommandType.StoredProcedure);

            return result;
        }

        public async Task<Department?> GetByIdAsync(int id)
        {
            var result = await _db.QueryFirstOrDefaultAsync<Department>(
                "dbo.usp_Department_GetById",
                new { DepartmentId = id },
                commandType: CommandType.StoredProcedure);

            return result;
        }

        public async Task<Department> InsertAsync(DepartmentCreateDto dto, int createdBy)
        {
            var result = await _db.QuerySingleAsync<Department>(
                "dbo.usp_Department_Insert",
                new
                {
                    DepartmentName = dto.DepartmentName,
                    Description = dto.Description,
                    CreatedBy = createdBy
                },
                commandType: CommandType.StoredProcedure);

            return result;
        }

        public async Task<Department> UpdateAsync(int id, DepartmentUpdateDto dto, int updatedBy)
        {
            var result = await _db.QuerySingleAsync<Department>(
                "dbo.usp_Department_Update",
                new
                {
                    DepartmentId = id,
                    DepartmentName = dto.DepartmentName,
                    Description = dto.Description,
                    UpdatedBy = updatedBy
                },
                commandType: CommandType.StoredProcedure);

            return result;
        }

        public async Task<string> DeleteAsync(int id)
        {
            // Your SP returns a SELECT 'Department deleted successfully.' AS Message;
            // So we read it as a string.
            var message = await _db.QuerySingleAsync<string>(
                "dbo.usp_Department_Delete",
                new { DepartmentId = id },
                commandType: CommandType.StoredProcedure);

            return message;
        }
    }
}
