﻿using System.Data;
using Dapper;
using EmployeeManagement.Domain.DTOs;
using EmployeeManagement.Domain.Models;
using EmployeeManagement.DAL.Interfaces;

namespace EmployeeManagement.DAL.Repositories
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly IDbConnection _db;

        public EmployeeRepository(IDbConnection db)
        {
            _db = db;
        }

        public async Task<IEnumerable<Employee>> GetAllAsync()
        {
            var result = await _db.QueryAsync<Employee>(
                "dbo.usp_Employee_GetAll",
                commandType: CommandType.StoredProcedure);

            return result;
        }

        public async Task<Employee?> GetByIdAsync(int id)
        {
            var result = await _db.QueryFirstOrDefaultAsync<Employee>(
                "dbo.usp_Employee_GetById",
                new { EmployeeId = id },
                commandType: CommandType.StoredProcedure);

            return result;
        }

        public async Task<IEnumerable<Employee>> GetByDepartmentAsync(int departmentId)
        {
            var result = await _db.QueryAsync<Employee>(
                "dbo.usp_Employee_GetByDepartment",
                new { DepartmentId = departmentId },
                commandType: CommandType.StoredProcedure);

            return result;
        }

        public async Task<Employee> InsertAsync(EmployeeCreateDto dto, int createdBy)
        {
            var result = await _db.QuerySingleAsync<Employee>(
                "dbo.usp_Employee_Insert",
                new
                {
                    FirstName = dto.FirstName,
                    LastName = dto.LastName,
                    Email = dto.Email,
                    PhoneNumber = dto.PhoneNumber,
                    HireDate = dto.HireDate,
                    Salary = dto.Salary,
                    DepartmentId = dto.DepartmentId,
                    CreatedBy = createdBy
                },
                commandType: CommandType.StoredProcedure);

            return result;
        }

        public async Task<Employee> UpdateAsync(int id, EmployeeUpdateDto dto, int updatedBy)
        {
            var result = await _db.QuerySingleAsync<Employee>(
                "dbo.usp_Employee_Update",
                new
                {
                    EmployeeId = id,
                    FirstName = dto.FirstName,
                    LastName = dto.LastName,
                    Email = dto.Email,
                    PhoneNumber = dto.PhoneNumber,
                    HireDate = dto.HireDate,
                    Salary = dto.Salary,
                    DepartmentId = dto.DepartmentId,
                    UpdatedBy = updatedBy
                },
                commandType: CommandType.StoredProcedure);

            return result;
        }

        public async Task<string> DeleteAsync(int id, int updatedBy)
        {
            var message = await _db.QuerySingleAsync<string>(
                "dbo.usp_Employee_Delete",
                new { EmployeeId = id, UpdatedBy = updatedBy },
                commandType: CommandType.StoredProcedure);

            return message;
        }
    }
}