﻿using EmployeeManagement.Domain.DTOs;
using EmployeeManagement.Domain.Models;

namespace EmployeeManagement.DAL.Interfaces
{
    public interface IDepartmentRepository
    {
        Task<IEnumerable<Department>> GetAllAsync();
        Task<Department?> GetByIdAsync(int id);
        Task<Department> InsertAsync(DepartmentCreateDto dto, int createdBy);
        Task<Department> UpdateAsync(int id, DepartmentUpdateDto dto, int updatedBy);
        Task<string> DeleteAsync(int id);
    }
}
